import login from './login.json';
import signup from './signup.json';
import subscribe from './subscribe.json';

export const auth = {
    login,
    signup,
    subscribe
};