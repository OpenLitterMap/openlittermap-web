import cityVueMap from './cityVueMap.json'
import countries from './countries.json'

export const locations = {
    cityVueMap,
    countries
}
