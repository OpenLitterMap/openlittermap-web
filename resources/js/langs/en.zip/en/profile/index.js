import dashboard from './dashboard.json';

export const profile = {
    dashboard
};